[Package title] : UnityMaskMan
[Description] : 
Coming straight from Japan and bursting into the world fighting scene is Unity Mask Man!. Well known for his magical feline mask that is powered by Unity, he strikes fear into any opponent he faces. 

Unity Mask Man Includes:
-Beautifully sculpted mask with its own 1024x1024 diffuse texture to emphasize how great it is!
-Well rounded body mesh that utilizes a separate 1024x1024 diffuse texture to show off his abs and stunning muscles!
-High quality spandex shorts, boots, tights and sweatbands!
-21 spectacular hand-crafted animations! 

Perfect for any fighting game you're making, or any game where you need your character to be a topless male with spandex and a feline mask! Other examples he could be used for would be FPS, RPG, RTS, MOBA, Dungeon Crawler, or Dating Sim! 

Click here  if you're ready to be dazzled by this demo.
http://demo.creator.ms/unitymaskman/